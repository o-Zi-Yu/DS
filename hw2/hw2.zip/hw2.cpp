#include <algorithm>
#include <fstream>
#include <iostream>
#include <vector>
#include <string>
#include <assert.h> 
#include <iomanip>
#include <math.h>
#include "hw2.h"

using namespace std;
// Here we use special syntax to call the string class copy constructors
//Athlete::Athlete();
// Alternative implementation first calls default string constructor for the two
// variables, then performs an assignment in the body of the constructor function.
/*
Name::Name(const std::string& fst, const std::string& lst) {
first_ = fst;
last_ = lst;
}
*/
// operator<
// bool operator< (const Name& left, const Name& right) {
// return left.last()<right.last() ||
// (left.last()==right.last() && left.first()<right.first());
// }
// // The output stream operator takes two arguments: the stream (e.g., cout) and the object
// // to print. It returns a reference to the output stream to allow a chain of output.
// std::ostream& operator<< (std::ostream& ostr, const Name& n) {
// ostr << n.first() << " " << n.last();
// return ostr;
// }
void ReadDataFromFileWBW(){
    ifstream fin("data.txt");  
    string s;  
    while( fin >> s ) {    
        cout << "Read from file: " << s << endl;  
    }
}
bool sorted1 (const Athlete& one, const Athlete& two) {
    return one.country()<two.country() ||
    (one.country()==two.country() && one.last_name()<two.last_name());
}

bool sorted2 (const Athlete& one, const Athlete& two) {
    return one.get_sum_point()<two.get_sum_point();
}


std::vector <Athlete> a_vector(std::ifstream& in_str){
    std::vector <Athlete> ath;
    std::string first, last, country, time;
    std::string event;
    //string::size_type test = test.find( "\0" );
    vector <string> all;
    while (!in_str.eof()) {
        in_str >> first;
        if (first == "event"){
            in_str >> event;
        }
        else {
            in_str >> last >> country >> time;
            Athlete b = Athlete(first, last, country);
            //cout << first << last << endl;
            bool exist = false;
            for (int i = 0; i < ath.size(); i++){
                if (ath[i].first_name() == first && ath[i].last_name() == last){
                    exist = true;
                    break;
                }
            }
            if (exist == false){
                b.set_first(first);
                b.set_last(last);
                ath.push_back(b);
            }
                
            
                //ath[i].set_last(last);
                    //b.set_POLE(time);
            for (int i = 0; i < ath.size(); i++){
                if (ath[i].first_name() == first && ath[i].last_name() == last){
                    if (event == "100_METERS"){
                    ath[i].set_score(time, 0);
                    }
                    if (event == "LONG_JUMP"){
                    ath[i].set_score(time, 1);
                    }
                    if (event == "SHOT_PUT"){
                    ath[i].set_score(time, 2);
                    }
                    if (event == "HIGH_JUMP"){
                    ath[i].set_score(time, 3);
                    }
                    if (event == "400_METERS"){
                    ath[i].set_score(time, 4);
                    }
                    if (event == "110_METERS_HURDLES"){
                    ath[i].set_score(time, 5);
                    }
                    if (event == "DISCUS_THROW"){
                    ath[i].set_score(time, 6);
                    }
                    if (event == "POLE_VAULT"){
                    ath[i].set_score(time, 7);
                    }
                    if (event == "JAVELIN_THROW"){
                    ath[i].set_score(time, 8);
                    }
                    if (event == "1500_METERS"){
                    ath[i].set_score(time, 9);
                    }
                }
                //cout << b.get_score(1) << endl;
            }
        }
    }
    return ath;
}


void out_score(std::ofstream& f_out, std::vector <Athlete> ath){
    sort(ath.begin(), ath.end(), sorted1);
    
    f_out << "DECATHLETE SCORES                   100     LJ     SP     HJ    400   110H     DT     PV     JT     1500" << endl;
    for(int i = 0; i < ath.size(); i++){
        f_out << std::left <<std::setw(14)<< ath[i].first_name() << std::left << std::setw(15) << ath[i].last_name();
        f_out << std::left << std::setw(5) << ath[i].country();
        f_out << ath[i].get_score(0);
        for (int j = 1; j < 9; j++){
            f_out << std::right << std::setw(7) << ath[i].get_score(j);
        }
        if (ath[i].get_score(9) == ""){
            f_out << std::right << std::setw(8) << ath[i].get_score(9);
        }
        else{
            f_out << std::right << std::setw(9) << ath[i].get_score(9);}
        f_out << endl;
    }
}

void cal_point(std::vector <Athlete> ath){
    for (int i = 0; i < ath.size(); i++){
        for (int j = 0; j < 9; j++){
            float p;
            float a = 25.4347 ;
            float b = 18 ;
            float c = 1.81;
            if (!ath[i].get_score(j).empty()){
                double s = std::stod(ath[i].get_score(j));
                p = a * pow((b - s), c);
                cout<<pow((b - s), c)<<endl;
                //cout<<p<<endl;
            }
            else{
                p = 0;
            }
            ath[i].set_point(p, j);
        }
        // int p;
        // float a = 0.03768;
        // float b = 480;
        // float c = 1.85;
        // if (!ath[i].get_score(10).empty()){
        //     std::string st = ath[i].get_score(10);
        //     int m;
        //     for (int i = 0; i < st.size(); i++){
        //     //string::size_type m = ath[i].get_score(10).find (':');
        //         if (st[i] == ':'){
        //             m = i;
        //         }
        //     }
        //     int minute = std::stoi(st.substr(0, m));
        //     double second = std::stod(st.substr((int) m));
        //     float s = minute*60 + second;
        //     p = int(a * pow((b - s), c));
        // }
        // else{
        //     p = 0;
        // }
        //ath[i].set_point(p, 10);
        int point_o = ath[i].add_point();
        ath[i].set_sum_point(point_o);
    }
}


void out_point(std::ofstream& f_out, std::vector <Athlete> ath){
    sort(ath.begin(), ath.end(), sorted2);
    f_out << "DECATHLETE POINTS                   100     LJ     SP     HJ    400   110H     DT     PV     JT   1500    TOTAL" << endl;
    for(int i = 0; i < ath.size(); i++){
        f_out << std::left <<std::setw(14)<< ath[i].first_name() << std::left << std::setw(15) << ath[i].last_name();
        f_out << std::left << std::setw(5) << ath[i].country();
        f_out << ath[i].get_point(0);
        for (int j = 1; j < 10; j++){
            f_out << std::right << std::setw(7) << ath[i].get_point(j);
        }
        f_out << std::right << std::setw(9) << ath[i].get_sum_point();
        f_out << endl;
    }
    
}

int main(int argc, const char * argv[]){
    //ath[1].first_name();
    std::ifstream in_str2(argv[1]);
    std::ofstream f_out(argv[2]);
    std::string type(argv[3]);
    if (!in_str2.good()) {
        std::cerr << "Can't open " << argv[1] << " to read.\n";
        exit(1);
    }
    std::vector <Athlete>v_athlete = a_vector(in_str2);

    if (type == "scores"){
        out_score(f_out, v_athlete);
    }
    if (type == "points"){
        cal_point(v_athlete);
        out_point(f_out, v_athlete);
    }

    // for(int i = 0; i < all.size(); i++){
    //     cout << all[i] << endl;
    // }
    //     if (all[i] == "event"{
    //         if
    //     })
    // }
    
    // while (in_str >> last_name) {
    //     in_str >> num_children;
    //     // error checking to make sure num_children is not negative
    //     assert (num_children >= 0);				  
    //     // clear out ages data from the last family
    //     ages.clear();  
    //     for (int i = 0; i < num_children; i++) {
    //         in_str >> tmp;
    //         ages.push_back(tmp);
    //     }				  
    // Do something interesting with the last_name and ages variables!
//   }
}
