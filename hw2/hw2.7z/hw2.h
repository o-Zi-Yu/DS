#ifndef __student_h_
#define __student_h_
#include <iostream>
#include <string>
#include <vector>
class Athlete {
    public:
        //Athlete(const std::string& fst="", const std::string& lst="", const std::string& cty="");
        Athlete(const std::string& fst, const std::string& lst, const std::string cty){
            first_name_ = fst;
            last_name_ = lst;
            country_ = cty;
        }
        // const std::string& fst="", const std::string& lst=""
        // ACCESSORS
        const std::string& first_name() const { return first_name_; }
        const std::string& last_name() const { return last_name_; }
        const std::string& country() const { return country_; }
        //const int& sum_point()const {return point_;}
        const std::string& get_score(int i) const { return score_a[i]; }
        int& get_point(int i) {return point_[i];}
        int& get_sum_point() {return point_sum;}
        
        void set_first(const std::string & fst) { first_name_ = fst; }
        void set_last(const std::string& lst) { last_name_ = lst; }
        void set_country(const std::string & cty) { country_ = cty; }
        void set_score(const std::string & score, int i) { 
            score_a[i] = score; 
        }
        void set_point(int point, int i) {
            point_[i] = point;
        }
        void add_point(){
            point_sum = 0;
            for (int i = 0; i < 10; i++){
                point_sum += point_[i];
            }
        }
    private:
        // REPRESENTATION
        // std::string first_, last_;
        std::string first_name_;
        std::string last_name_;
        std::string country_;
        std::string score_a[10];
        int point_[10] = {0,0,0,0,0,0,0,0,0,0};
        int point_sum;
        // std::vector<int> hw_scores_;
        // double hw_avg_;
        // std::vector<int> test_scores_;
        // double test_avg_;
        // double final_avg_;
};
#endif